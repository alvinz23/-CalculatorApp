package tests;

import calculator.model.Calculator;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestCalculator {

    @Test
    public void testDisplay() {
        Calculator calculator = new Calculator();
        assertEquals(0.0, calculator.displayNumber(),0.001);
    }

    @Test
    public void testNumberPressing(){
        Calculator calc = new Calculator();
        calc.numberPressed(1);
        calc.numberPressed(2);
        assertEquals(calc.displayNumber(),12.0,0.001);

        Calculator calc2 = new Calculator();
        calc2.numberPressed(5);
        calc2.numberPressed(5);
        calc2.numberPressed(5);
        assertEquals(calc2.displayNumber(),555.0,0.001);
    }

    @Test
    public void testAdding() {
        Calculator calc = new Calculator();
        calc.numberPressed(2);
        calc.addPressed();
        calc.numberPressed(3);
        calc.equalsPressed();
        assertEquals(calc.displayNumber(),5.0,0.001);
    }

    @Test
    public void testSubtraction() {
        Calculator calculator = new Calculator();
        calculator.numberPressed(3);
        calculator.subtractPressed();
        calculator.numberPressed(5);
        calculator.equalsPressed();
        assertEquals(-2.0, calculator.displayNumber(), 0.001);
    }

    @Test
    public void testSubtraction2() {
        Calculator calculator = new Calculator();
        calculator.numberPressed(5);
        calculator.subtractPressed();
        calculator.numberPressed(3);
        calculator.equalsPressed();
        assertEquals(2.0, calculator.displayNumber(), 0.001);

        calculator.clearPressed();
        calculator.numberPressed(8);
        calculator.numberPressed(0);
        calculator.addPressed();
        calculator.numberPressed(1);
        calculator.numberPressed(0);
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        assertEquals(calculator.displayNumber(), 120.0,0.001);
    }
    @Test
    public void testEqualMultipleTimes(){
        Calculator calculator = new Calculator();
        calculator.numberPressed(8);
        calculator.numberPressed(0);
        calculator.addPressed();
        calculator.numberPressed(1);
        calculator.numberPressed(0);
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        assertEquals(calculator.displayNumber(), 120.0,0.001);
    }
    @Test
    public void testEqualMultipleTimes2(){
        Calculator calculator = new Calculator();
        calculator.clearPressed();
        calculator.numberPressed(3);
        calculator.addPressed();
        calculator.numberPressed(4);
        calculator.equalsPressed();
        calculator.multiplyPressed();
        calculator.numberPressed(2);
        calculator.equalsPressed();
        calculator.equalsPressed();
        assertEquals(calculator.displayNumber(), 28.0,0.001);
    }

    @Test
    public void testMultiply(){
        Calculator calc = new Calculator();
        calc.numberPressed(3);
        calc.multiplyPressed();
        calc.numberPressed(4);
        calc.equalsPressed();
        assertEquals(12.0, calc.displayNumber(),0.001);
    }

    @Test
    public void testDivide(){
        Calculator calc = new Calculator();
        calc.numberPressed(1);
        calc.numberPressed(0);
        calc.dividePressed();
        calc.numberPressed(5);
        calc.equalsPressed();
        assertEquals(2.0,calc.displayNumber(),0.001);
    }

//    @Test
//    public void testMultiply2() {
//        Calculator calc = new Calculator();
//        calc.numberPressed(3);
//        calc.multiplyPressed();
//        calc.numberPressed(4);
//        calc.multiplyPressed();
//        calc.numberPressed(2);
//        calc.equalsPressed();
//        assertEquals(24.0, calc.displayNumber());
//    }
    @Test
    public void testMultiply3() {
        Calculator calc = new Calculator();
        calc.numberPressed(3);
        calc.multiplyPressed();
        calc.numberPressed(4);
        calc.equalsPressed();
        assertEquals(12.0, calc.displayNumber(),0.001);
    }

    @Test
    public void testMultipleDigits(){
        Calculator calc = new Calculator();
        calc.numberPressed(1);
        calc.numberPressed(2);
        calc.numberPressed(3);
        calc.subtractPressed();
        calc.numberPressed(3);
        calc.equalsPressed();
        assertEquals(120.0,calc.displayNumber(),0.001);
    }
    @Test
    public void testMultipleOperator(){
        Calculator calculator = new Calculator();
        calculator.numberPressed(5);
        calculator.addPressed();
        calculator.numberPressed(1);
        calculator.numberPressed(0);
        calculator.equalsPressed();
        assertEquals(15.0,calculator.displayNumber(),0.001);
        calculator.clearPressed();
        calculator.numberPressed(5);
        calculator.addPressed();
        calculator.numberPressed(9);
        calculator.equalsPressed();
        calculator.multiplyPressed();
        calculator.numberPressed(2);
        calculator.equalsPressed();
        assertEquals(calculator.displayNumber(), 28.0,0.001);

    }

    @Test
    public void testDecimal() {
        Calculator calc = new Calculator();
        calc.numberPressed(3);
        calc.decimalPressed();
        calc.numberPressed(5);
        calc.equalsPressed();
        assertEquals(3.5, calc.displayNumber(), 0.001);
    }

    @Test
    public void testDecimal2() {
        Calculator calc = new Calculator();
        calc.numberPressed(1);
        calc.numberPressed(2);
        calc.decimalPressed();
        calc.numberPressed(5);
        calc.decimalPressed();
        calc.decimalPressed();
        calc.numberPressed(0);
        calc.decimalPressed();
        calc.numberPressed(5);
        calc.equalsPressed();
        assertEquals(12.505, calc.displayNumber(), 0.001);
    }

    @Test
    public void testNew(){
        Calculator calculator = new Calculator();
        calculator.numberPressed(5);
        calculator.numberPressed(0);
        calculator.subtractPressed();
        calculator.numberPressed(1);
        calculator.numberPressed(0);
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        assertEquals(calculator.displayNumber(), 10.0,0.001);
    }

    @Test
    public void testNew1(){
        Calculator calculator = new Calculator();
        calculator.numberPressed(8);
        calculator.numberPressed(0);
        calculator.subtractPressed();
        calculator.numberPressed(1);
        calculator.numberPressed(0);
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        calculator.equalsPressed();
        assertEquals(calculator.displayNumber(), 40.0,0.001);
    }

    @Test
    public void testNew2(){
        Calculator calculator = new Calculator();
        calculator.numberPressed(2);
        calculator.multiplyPressed();
        calculator.numberPressed(2);
        calculator.equalsPressed();
        calculator.equalsPressed();
        assertEquals(calculator.displayNumber(), 8.0,0.001);
    }

    @Test
    public void testNew3(){
        Calculator calculator = new Calculator();
        calculator.numberPressed(9);
        calculator.dividePressed();
        calculator.numberPressed(3);
        calculator.equalsPressed();
        calculator.equalsPressed();
        assertEquals(calculator.displayNumber(), 1.0,0.001);
    }








}
