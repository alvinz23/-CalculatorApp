package calculator.model;

public interface Operation {
//    void numberPressed(Calculator calculator, int number);
    void decimalPressed(Calculator calculator);
    void performOperation(Calculator calculator);
    void equalsPressed(Calculator calculator);
}