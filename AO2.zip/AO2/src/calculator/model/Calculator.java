package calculator.model;

import java.util.LinkedList;
import java.util.Stack;
import java.util.function.BinaryOperator;

public class Calculator {
    private String currentNumber;
    private double currentResult;
    private Operation currentOperation;

    private Operation previousOperation;

    public Calculator() {
        currentNumber = "";
        currentResult = 0.0;
        currentOperation = new AddOperation(0.0);
    }

    public void numberPressed(int number) {
        currentNumber += number;
        setCurrentResult(Double.parseDouble(currentNumber));
    }

    public void decimalPressed() {
        currentOperation.decimalPressed(this);
    }

    public void addPressed() {
        double previousNumber = Double.parseDouble(currentNumber);
        currentNumber = "";
        currentOperation=new AddOperation(previousNumber);
    }

    public void subtractPressed() {
        double previousNumber = Double.parseDouble(currentNumber);
        currentNumber = "";
        currentOperation = new SubtractOperation(previousNumber);
    }

    public void multiplyPressed() {
        double previousNumber = Double.parseDouble(currentNumber);
        currentNumber = "";
        currentOperation = new MultiplyOperation(previousNumber);
    }

    public void dividePressed() {
        double previousNumber = Double.parseDouble(currentNumber);
        currentNumber = "";
        currentOperation = new DivideOperation(previousNumber);
    }

    public void equalsPressed() {
        currentOperation.equalsPressed(this);
    }

    public void clearPressed() {
        currentNumber = "";
        currentResult = 0.0;
        currentOperation = null;
    }

    public double displayNumber() {
        return currentResult;
    }
    public String getCurrentNumber(){
        return currentNumber;
    }
    public void setCurrentNumber(String currentNumber){
        this.currentNumber = currentNumber;
    }

    public void setCurrentResult(double currentResult) {
        this.currentResult = currentResult;
    }

    public void setPreviousOperation(Operation previousOperation) {
        this.previousOperation = previousOperation;
    }

    public Operation getCurrentOperation() {
        return currentOperation;
    }
    public void setCurrentOperation() {
        this.currentOperation=currentOperation;
    }


}
