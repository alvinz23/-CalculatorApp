package calculator.model;

public class SubtractOperation implements Operation {
    private Double firstNumber;
    private Double secondNumber;
    private int operationCount;
    private Double previousNumber;

    public SubtractOperation(Double firstNumber) {
        this.firstNumber = firstNumber;
        this.secondNumber = 0.0;
        this.operationCount = 0;
    }

//    @Override
//    public void numberPressed(Calculator calculator, int number) {
//        String newNumber = calculator.getCurrentNumber() + number;
//        calculator.setCurrentNumber(newNumber);
//    }

    @Override
    public void performOperation(Calculator calculator) {
//        this.previousNumber = Double.parseDouble(calculator.getCurrentNumber());
//        calculator.setCurrentNumber("");
    }

    @Override
    public void equalsPressed(Calculator calculator) {
        operationCount++;
        secondNumber = operationCount == 1 ? Double.parseDouble(calculator.getCurrentNumber()) : secondNumber;
        double result = firstNumber - secondNumber;
        firstNumber = result;
        calculator.setCurrentResult(result);
        calculator.setCurrentNumber(Double.toString(result));
    }

    @Override
    public void decimalPressed(Calculator calculator) {
        // Implement decimalPressed functionality if needed, or leave empty
    }
}
