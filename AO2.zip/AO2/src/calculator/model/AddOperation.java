package calculator.model;

public class AddOperation implements Operation {
    private Double previousNumber;
    private Double lastOperand;

    private int repeatEquals;
    private Double initialPreviousNumber;

    private Double firstNumber;
    private Double secondNumber;
    private int operationCount;


    public AddOperation(Double firstNumber) {
        this.firstNumber = firstNumber;
        this.secondNumber = 0.0;
        this.operationCount = 0;
    }

//    @Override
//    public void numberPressed(Calculator calculator, int number) {
////        String newNumber = calculator.getCurrentNumber() + number;
////        calculator.setCurrentNumber(newNumber);
//
//    }

    @Override
    public void performOperation(Calculator calculator) {
//        this.previousNumber = Double.parseDouble(calculator.getCurrentNumber());
//        calculator.setCurrentNumber("");
    }

    @Override
    public void equalsPressed(Calculator calculator) {
        operationCount++;
        secondNumber = operationCount == 1 ? Double.parseDouble(calculator.getCurrentNumber()) : secondNumber;
        double result = firstNumber + secondNumber;
        firstNumber = result;
        calculator.setCurrentResult(result);
        calculator.setCurrentNumber(Double.toString(result));
    }

    @Override
    public void decimalPressed(Calculator calculator) {
        // Implement decimalPressed functionality if needed, or leave empty
        String currentNumber = calculator.getCurrentNumber();
        String[] parts = currentNumber.split("\\.");
        currentNumber += parts.length < 2 ? "." : "";
        calculator.setCurrentNumber(currentNumber);
    }

    public void setLastOperand(double lastOperand) {
        this.lastOperand = lastOperand;
    }







    // Implement the methods from Operation interface
}

// Do the same for SubtractOperation, MultiplyOperation, and DivideOperation

